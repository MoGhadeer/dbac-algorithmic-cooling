# dbac
This is the repository for the paper **Double-bracket quantum algorithm for qubit reset implemented with multicolor-driven superconducting qubits**

In this repo, there will be:
- DME
- DBAC
- circuit draw

View `jupyter_notebooks` for DME and DBAC notebooks. View `functions` for basic function and classes.
The notebook `dbac_main_plot.ipynb` shows the main result (which is currently Fig. 4 in the Overleaf).
The notebook `dbac_ideal_dme_(rainbow_plot).ipynb` shows the dbac steps for the case of ideal DME (Fig. 7).
