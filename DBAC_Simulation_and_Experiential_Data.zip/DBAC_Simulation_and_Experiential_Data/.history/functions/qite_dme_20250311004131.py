
from qibo import hamiltonians

L = 1
H_sh = hamiltonians.SymbolicHamiltonian(Z(0), nqubits = 1)
H = - H_sh.matrix
eigs = H_sh.eigenvalues()
target_energy = min(eigs)