import numpy as np
from scipy.linalg import expm

def dme_expm(a,b, s, muq = 40):
    V = expm(1j*s*b) 
    return V @ a @ V.conj().T