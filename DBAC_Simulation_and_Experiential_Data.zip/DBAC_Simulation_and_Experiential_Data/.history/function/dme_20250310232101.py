import numpy as np
from scipy.linalg import expm
from qibo.quantum_info.linalg_operations import matrix_exponentiation, partial_trace
from qibo.gates import SWAP

def dme_expm(data, instruction, t, M = None):
    V = expm(1j*t*instruction)
    return V @ data @ V.conj().T

def dme_qibo(data,instruction,t,M):
    rho_list = []
    _t = t/M
    u = matrix_exponentiation(-_t,SWAP(0,1).matrix())
    dme_state = np.kron(data,instruction)
    for _i in range(M):
        dme_state = u @ dme_state @ u.T.conj()
        data = partial_trace(dme_state,[1])
        rho_list.append(data)
        dme_state = np.kron(data,instruction)
    return data, rho_list